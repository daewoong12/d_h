from django.shortcuts import render,get_object_or_404,redirect
from .models import Stuff,Cart,Order
from .forms import StuffForm
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from datetime import datetime,timedelta
from .models import Order
# Create your views here.

def index(request):
    stuffs=Stuff.objects.all()
    context={'stuffs':stuffs}
    return render(request,'mall/index.html',context)

def detail(request,stuff_id):
    stuff=Stuff.objects.get(id=stuff_id)
    context={'stuff':stuff}
    return render(request,'mall/detail.html',context)

def register_stuff(request):
    if request.method == 'POST':
        form = StuffForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('mall:index')  # 물품 목록 페이지로 리다이렉트
    else:
        form = StuffForm()
    return render(request, 'mall/register.html', {'form': form})
    
def cancel_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    if order:
        order.delete()
        messages.success(request, "주문이 성공적으로 취소되었습니다.")
    else:
        messages.error(request, "주문 취소에 실패했습니다.")

    return redirect('mall:info')  # 'order_list'는 주문 목록 페이지의 URL 이름입니다.

@login_required(login_url='common:login')
def info(request):
    orders=Order.objects.filter(user=request.user)
    pub_times=[]
    orderlists=[]
    for order in orders:
        pub_times.append(order.order_date)
    pub_times=list(set(pub_times))
    for pub_time in pub_times:
        total=0
        orders=Order.objects.filter(order_date=pub_time)
        for order in orders:
            total+=order.subtotal
        orderlists.append([orders,total])
    context={'orderlists':orderlists,'username':request.user.username,'email':request.user.email}
    return render(request,'mall/info.html',context)

@login_required(login_url='common:login')
def cart(request):
    uCart=Cart.objects.filter(user=request.user)
    stuffs=uCart
    context={'stuffs':stuffs}
    return render(request,'mall/cart.html',context)

@login_required(login_url='common:login')
def addCart(request,stuff_id):
    uCart=Cart.objects.filter(user=request.user)
    stuff=Stuff.objects.get(id=stuff_id)
    for uCart2 in uCart:
        if uCart2.stuffs.id==stuff_id:
            uCart2.quantity+=1
            uCart2.save()
            break
    else:
        uCart2=Cart.objects.create(user=request.user,stuffs=stuff)
        uCart2.quantity+=1
        uCart2.save()
        
    return  redirect('mall:cart')

@login_required(login_url='common:login')
def subCart(request,stuff_id):
    uCart=Cart.objects.filter(user=request.user)
    for uCart2 in uCart:
        if uCart2.stuffs.id==stuff_id:
            uCart2.delete()
            break
    return  redirect('mall:cart')

@login_required(login_url='common:login')
def plusStuff(request,stuff_id):
    uCart=Cart.objects.filter(user=request.user)
    for uCart2 in uCart:
        if uCart2.stuffs.id==stuff_id:
            uCart2.quantity+=1
            uCart2.save()
            break
    return  redirect('mall:cart')

@login_required(login_url='common:login')
def minusStuff(request,stuff_id):
    uCart=Cart.objects.filter(user=request.user)
    for uCart2 in uCart:
        if uCart2.stuffs.id==stuff_id:
            uCart2.quantity-=1
            uCart2.save()
            if uCart2.quantity==0:
                uCart2.delete()
            break
    return  redirect('mall:cart')


@login_required(login_url='common:login')
def buyAtIndex(request,stuff_id):
    uCart=Cart.objects.filter(user=request.user)
    stuff=Stuff.objects.get(id=stuff_id)
    for uCart2 in uCart:
        if uCart2.stuffs.id==stuff_id:
            uCart2.quantity+=1
            uCart2.save()
            break
    else:
        uCart2=Cart.objects.create(user=request.user,stuffs=stuff)
        uCart2.quantity+=1
        uCart2.save()
    return  redirect('mall:cart')

@login_required(login_url='common:login')
def buy(request):
    subtotal = 0
    order_date = datetime.now()
    
    if request.method == 'POST':
        uCarts = Cart.objects.filter(user=request.user)
        
        for uCart in uCarts:
            if request.POST.get(uCart.stuffs.name):
                stuff_name = request.POST[uCart.stuffs.name]
                stuff = Stuff.objects.get(name=stuff_name)
                uCart = Cart.objects.get(user=request.user, stuffs=stuff)
                
                # 재고 확인 및 감소
                if stuff.stock >= uCart.quantity:
                    # 주문 생성
                    orderlist = Order.objects.create(
                        user=request.user,
                        stuff=uCart.stuffs,
                        order_date=order_date,
                        quantity=uCart.quantity
                    )
                    subtotal = uCart.quantity * uCart.stuffs.price
                    orderlist.subtotal = subtotal
                    orderlist.save()
                    
                    # 재고 감소
                    stuff.stock -= uCart.quantity
                    stuff.save()
                    
                    # 장바구니 항목 삭제
                    uCart.delete()
                else:
                    # 재고 부족 시 메시지 표시
                    return render(request, 'mall/error.html', {'message': f'{stuff.name}의 재고가 부족합니다.'})
        
        # 주문 목록 생성
        orders = Order.objects.filter(user=request.user)
        pub_times = []
        orderlists = []
        
        for order in orders:
            pub_times.append(order.order_date)
        
        pub_times = list(set(pub_times))
        
        for pub_time in pub_times:
            orders = Order.objects.filter(order_date=pub_time)
            total = 0
            for order in orders:
                total += order.subtotal
            orderlists.append([orders, total])
        
        context = {
            'orderlists': orderlists,
            'username': request.user.username,
            'email': request.user.email
        }
    else:
        context = {
            'username': request.user.username,
            'email': request.user.email
        }
    
    return render(request, 'mall/info.html', context)

def product_list(request):
    stuffs = Stuff.objects.all()  # 등록된 모든 물품 가져오기
    return render(request, 'mall/index.html', {'stuffs': stuffs})

def add_to_cart(request, stuff_id):
    stuff = get_object_or_404(Stuff, id=stuff_id)

    if stuff.stock > 0:  # 재고가 있는 경우에만 추가 가능
        cart_item, created = Cart.objects.get_or_create(user=request.user, stuffs=stuff)
        if not created:
            cart_item.quantity += 1  # 이미 존재하면 수량 증가
        cart_item.save()

        # 재고 감소
        stuff.stock -= 1
        stuff.save()

        return redirect('mall:cart')
    else:
        return render(request, 'mall/error.html', {'message': '재고가 부족합니다.'})